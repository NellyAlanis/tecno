<?php

$connection = mysqli_connect('localhost', 'root', '', 'tecnat') 
or die(mysql_error($mysqli));

echo "Se ha realizado su compra con exito"

?>